Run from the extracted source directory: node --test tests/core.test.mjs
