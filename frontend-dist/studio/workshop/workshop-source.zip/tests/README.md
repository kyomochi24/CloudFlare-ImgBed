From the source directory: node --test tests/*.test.mjs
