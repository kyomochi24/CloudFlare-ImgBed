import { colorRgb, exportTheme, inspectTheme, mapColor, familyMatches, mapFamilyColor, isNeutralColor, migrateColorChanges } from './candy-utils.js?v=20261015a';
import { initProtectionEditor } from './candy-protection.js?v=20261014b';
import { initCandyThemePreview } from './candy-theme-preview.js?v=20261105a';
import { DEFAULT_RECOLOR, recolorCanvas, sampleColor } from './candy-recolor.js?v=20261014b';

const $ = id => document.getElementById(id);
const safe = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c]);
const uploadTypes = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/avif', 'image/bmp']);
const draftDb = () => new Promise((resolve, reject) => {
  const request = indexedDB.open('studio-candy-drafts', 1);
  request.onupgradeneeded = () => request.result.createObjectStore('drafts', { keyPath: 'id' });
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});
async function drafts(mode, callback) {
  const db = await draftDb();
  try { return await new Promise((resolve, reject) => {
    const transaction = db.transaction('drafts', mode), request = callback(transaction.objectStore('drafts'));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    transaction.onerror = () => reject(transaction.error);
  }); } finally { db.close(); }
}
const waitImage = blob => createImageBitmap(blob);
const filter = item => `hue-rotate(${item.hue}deg) saturate(${item.sat}%) brightness(${item.light}%)`;
const imageRules = item => item.recolors?.length ? item.recolors : [{ ...(item.recolor || DEFAULT_RECOLOR) }];
const edited = item => !!item.override || (item.mode === 'selective' ? imageRules(item).some(rule => rule.source !== rule.target) : item.hue !== 0 || item.sat !== 100 || item.light !== 100);
const shortName = (name, index) => `${String(name || '糖果色').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').slice(0, 58)}-${index + 1}.png`;

export function initCandy({ api, state, refreshProfile, refreshAlbums, notice }) {
  let project = null, busy = false;
  let mappedFrom = -1;
  let activeRuleIndex = 0;
  const selected = new Set();
  const selectedColors = new Set();
  const previewSources = new Map();
  const themeAssets = new Map();
  let previewTimer, previewVersion = 0, picking = false;
  const visibleImages = new Set();
  const imageObserver = new IntersectionObserver(entries => {
    for (const entry of entries) {
      const n = Number(entry.target.dataset.imageRow);
      entry.isIntersecting ? visibleImages.add(n) : visibleImages.delete(n);
    }
    schedulePreview();
  }, { rootMargin: '180px' });
  const status = message => { $('candy-status').textContent = message; };
  const themePreview = initCandyThemePreview({buildSnapshot:buildThemeSnapshot,notice});
  const protector = initProtectionEditor({
    sourceFor: previewSource,
    onApply(item, index, strokes) {
      if (project?.images[index] !== item) return;
      item.protection = strokes; item.savedUrl = ''; item.keep = false;
      themePreview.markDirty();
      updateProtectionButtons(); updatePreview();
      status('第 ' + (index + 1) + ' 张的保护区域已更新；其他图片没有更改。');
    },
    notice,
  });
  function release() {
    themePreview.close(); themeAssets.clear();
    protector.close();
    previewVersion++; clearTimeout(previewTimer); picking = false;
    imageObserver.disconnect(); visibleImages.clear(); previewSources.clear();
    for (const item of project?.images || []) if (item.overrideUrl) URL.revokeObjectURL(item.overrideUrl);
  }
  function imageMode(item) { return item?.mode === 'selective' ? 'selective' : 'global'; }
  function setPicking(value) {
    picking = value;
    $('candy-pick-color').setAttribute('aria-pressed', String(value));
    $('candy-pick-color').textContent = value ? '取消取色' : '✦ 从原图取色';
    $('candy-images').classList.toggle('is-picking', value);
    $('candy-palette').classList.toggle('is-sampling', value);
    $('candy-pick-hint').textContent = value ? '点一下左侧原图里的颜色；按 Esc 取消。' : '只改相近色，保留原图明暗与透明度。';
    $('candy-images').querySelectorAll('[data-before]').forEach(img => {
      img.tabIndex = value ? 0 : -1;
      if (value) { img.setAttribute('role', 'button'); img.setAttribute('aria-label', '在原图中取色；键盘 Enter 取图片中心颜色'); }
      else { img.removeAttribute('role'); img.removeAttribute('aria-label'); }
    });
  }
  function syncPalette() {
    const first = project?.images[[...selected][0]], mode = imageMode(first);
    $('candy-global-controls').classList.toggle('hidden', mode !== 'global');
    $('candy-selective-controls').classList.toggle('hidden', mode !== 'selective');
    $('candy-palette').querySelectorAll('[data-candy-mode]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.candyMode === mode));
      button.disabled = !first;
    });
    const rules = first ? imageRules(first) : [DEFAULT_RECOLOR];
    activeRuleIndex = Math.min(activeRuleIndex, rules.length - 1);
    const rule = rules[activeRuleIndex];
    $('candy-rule-add').disabled = !first || rules.length >= 6;
    $('candy-rules').innerHTML = rules.map((rule, index) => `<div class="candy-rule-row"><button type="button" data-rule-pick="${index}" aria-pressed="${index === activeRuleIndex}" aria-label="编辑第 ${index + 1} 条换色规则"><span>${index + 1}</span><i style="background:${safe(rule.source)}"></i><span>→</span><i style="background:${safe(rule.target)}"></i><small>${index === activeRuleIndex ? '正在调整' : '点击调整'}</small></button><button type="button" data-rule-delete="${index}" ${rules.length === 1 ? 'disabled' : ''} aria-label="删除第 ${index + 1} 条换色规则">×</button></div>`).join('');
    for (const key of ['source', 'target', 'range', 'softness']) $('candy-recolor-' + key).value = rule[key];
    $('candy-recolor-range-value').textContent = rule.range + '°';
    $('candy-recolor-softness-value').textContent = rule.softness + '%';
    $('candy-source-hex').textContent = rule.source.toUpperCase();
    $('candy-target-hex').textContent = rule.target.toUpperCase();
    $('candy-show-mask').disabled = mode !== 'selective' || !first;
    $('candy-protection-open').disabled = mode !== 'selective' || !first || first.keep;
    $('candy-protection-open').textContent = first?.protection?.length ? '✎ 编辑保护区域' : '✎ 保护区域';
    if (mode !== 'selective') { $('candy-show-mask').checked = false; setPicking(false); }
  }
  function imageSummary(item) {
    const rules = imageRules(item);
    return imageMode(item) === 'selective' ? (rules.length > 1 ? `指定颜色 · ${rules.length} 条换色规则` : `指定颜色 ${rules[0].source.toUpperCase()} → ${rules[0].target.toUpperCase()}`) : `色相 ${item.hue}° · 饱和度 ${item.sat}% · 亮度 ${item.light}%`;
  }
  async function refreshQuota() {
    if (!state.user) return;
    const q = await api('candy/quota');
    $('candy-quota').textContent = q.dailyLimit === null ? `今天已生成 ${q.used} 份 · 超级无敌美化大师丘不限量 · 北京时间 00:00 重置` : `今天已生成 ${q.used} / ${q.dailyLimit} 份 · 还可生成 ${q.remaining} 份 · 北京时间 00:00 重置`;
    return q;
  }
  async function refreshDrafts() {
    if (!state.user) return;
    try {
      const all = await drafts('readonly', store => store.getAll());
      const own = all.filter(draft => draft.userId === state.user.id).sort((a, b) => b.updatedAt - a.updatedAt);
      $('candy-drafts').innerHTML = `<option value="">本机保存的草稿（${own.length}）</option>${own.map(d => `<option value="${safe(d.id)}">${safe(d.name)} · ${new Date(d.updatedAt).toLocaleDateString('zh-CN')}</option>`).join('')}`;
    } catch { $('candy-drafts').innerHTML = '<option value="">此浏览器无法保存草稿</option>'; }
  }
  function preview(item) { return item.overrideUrl || item.url; }
  function updateSelection() {
    $('candy-selected-count').textContent = `已选 ${selected.size} 张`;
    $('candy-palette-count').textContent = selected.size ? `正在调整 ${selected.size} 张图片` : '先选择图片再调色';
    $('candy-images').querySelectorAll('[data-image-row]').forEach(row => row.classList.toggle('is-selected', selected.has(Number(row.dataset.imageRow))));
    const first = project?.images[[...selected][0]];
    if (first) for (const [key, slider, number] of [['hue','candy-hue','candy-hue-number'],['sat','candy-sat','candy-sat-number'],['light','candy-light','candy-light-number']]) {
      $(slider).value = first[key]; $(number).value = first[key];
    }
    syncPalette();
    schedulePreview();
  }
  function showPalette(show) {
    if (!show) setPicking(false);
    $('candy-palette').classList.toggle('hidden', !show);
    $('candy-images').classList.toggle('palette-open', show);
    $('candy-palette-open').setAttribute('aria-expanded', String(show));
    $('candy-palette-open').textContent = show ? '✿ 收起悬浮调色盘' : '✿ 打开悬浮调色盘';
  }
  function updatePreview() {
    $('candy-images').querySelectorAll('[data-after]').forEach(img => {
      const item = project.images[Number(img.dataset.after)];
      img.src = item.keep ? item.url : preview(item);
      img.style.filter = item.keep || imageMode(item) === 'selective' ? 'none' : filter(item);
      const canvas = img.parentElement.querySelector('[data-canvas]');
      if (item.keep || imageMode(item) !== 'selective') {
        canvas.classList.add('hidden'); img.classList.remove('hidden');
        img.parentElement.querySelector('.candy-after-title').textContent = '改后 · 实时预览';
        img.closest('[data-image-row]').querySelector('.candy-image-status').textContent = '';
      }
    });
    updateProtectionButtons();
    schedulePreview();
  }
  function schedulePreview() {
    const version = ++previewVersion;
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => renderSelectivePreviews(version), 90);
  }
  async function previewSource(item) {
    const key = item.override || item.url;
    if (previewSources.has(key)) {
      const cached = previewSources.get(key); previewSources.delete(key); previewSources.set(key, cached); return cached;
    }
    const blob = item.override || await sourceBlob(item.url), bitmap = await waitImage(blob);
    try {
      if (bitmap.width * bitmap.height > 20_000_000) throw new Error('单张图片超过 2000 万像素，请先缩小原图');
      const ratio = Math.min(1, 768 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * ratio)); canvas.height = Math.max(1, Math.round(bitmap.height * ratio));
      canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      previewSources.set(key, canvas);
      while (previewSources.size > 6) previewSources.delete(previewSources.keys().next().value);
      return canvas;
    } finally { bitmap.close(); }
  }
  async function buildThemeSnapshot(progress, isCurrent) {
    if (!project) throw new Error('请先导入一份美化');
    const raw = project.raw, title = $('candy-title').value.trim() || project.name;
    const changes = new Map(Object.entries(project.changes).map(([index,hex])=>[Number(index),hex]));
    // Snapshot settings now; preview processing never mutates the project or saved URLs.
    const items = project.images.filter(item=>!item.keep&&edited(item)).map(item=>({
      ...item,recolors:structuredClone(imageRules(item)),protection:structuredClone(item.protection||[]),
    }));
    const replacements = new Map(), assets = [];
    for (const [index,item] of items.entries()) {
      if(!isCurrent())return null;
      progress('正在准备预览图片 ' + (index+1) + ' / ' + items.length + '…');
      const key = item.override || item.url;
      const settings = JSON.stringify([imageMode(item),item.hue,item.sat,item.light,item.recolors,item.protection]);
      let blob = themeAssets.get(key)?.settings === settings ? themeAssets.get(key).blob : null;
      if (!blob) {
        const source = await previewSource(item);
        if(!isCurrent())return null;
        const canvas = document.createElement('canvas'), ratio = Math.min(1,512/Math.max(source.width,source.height));
        canvas.width = Math.max(1,Math.round(source.width*ratio)); canvas.height = Math.max(1,Math.round(source.height*ratio));
        const ctx = canvas.getContext('2d');
        if(!ctx)throw new Error('浏览器无法创建预览画布');
        if(imageMode(item)!=='selective'&&typeof ctx.filter!=='string'&&(item.hue!==0||item.sat!==100||item.light!==100))throw new Error('此浏览器不支持整图调色预览，请换用新版浏览器');
        if(imageMode(item)!=='selective')ctx.filter=filter(item);
        ctx.drawImage(source,0,0,canvas.width,canvas.height);
        if(imageMode(item)==='selective')await recolorCanvas(canvas,item.recolors,{strokes:item.protection,yieldToUI:true});
        blob = await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));canvas.width=0;canvas.height=0;
        if(!blob)throw new Error('预览图片生成失败');
        themeAssets.delete(key);themeAssets.set(key,{settings,blob});
        while(themeAssets.size>24)themeAssets.delete(themeAssets.keys().next().value);
      }
      const token='https://qiuqiu-preview.invalid/'+crypto.randomUUID()+'.png';
      replacements.set(item.url,token);assets.push({key:token,blob});
    }
    if(!isCurrent())return null;
    return {theme:JSON.parse(exportTheme(raw,title,replacements,changes)),assets};
  }
  async function renderSelectivePreviews(version) {
    const current = project; if (!current) return;
    for (const n of visibleImages) {
      const item = current.images[n];
      if (!item || item.keep || imageMode(item) !== 'selective') continue;
      const row = $('candy-images').querySelector(`[data-image-row="${n}"]`);
      if (!row) continue;
      const hint = row.querySelector('.candy-image-status');
      try {
        hint.textContent = '正在预览…';
        const source = await previewSource(item);
        if (version !== previewVersion || current !== project) return;
        const canvas = row.querySelector('[data-canvas]');
        canvas.width = source.width; canvas.height = source.height;
        canvas.getContext('2d').drawImage(source, 0, 0);
        const mask = $('candy-show-mask').checked && selected.has(n);
        await recolorCanvas(canvas, imageRules(item), { mask, strokes: item.protection });
        if (version !== previewVersion || current !== project) return;
        canvas.classList.remove('hidden'); row.querySelector('[data-after]').classList.add('hidden');
        row.querySelector('.candy-after-title').textContent = mask ? '粉色标记 · 将改色的范围' : '改后 · 实时预览';
        hint.textContent = '';
      } catch (error) {
        if (version !== previewVersion || current !== project) return;
        row.querySelector('[data-canvas]').classList.add('hidden');
        row.querySelector('[data-after]').classList.remove('hidden');
        hint.textContent = error.message + '。可上传手改图后重试。';
      }
    }
  }
  function renderImages() {
    imageObserver.disconnect(); visibleImages.clear(); previewVersion++; setPicking(false);
    $('candy-image-count').textContent = `共 ${project.images.length} 张`;
    $('candy-images').innerHTML = project.images.map((item, i) => `<article class="candy-image-row" data-image-row="${i}"><div class="candy-row-top"><label><input type="checkbox" data-pick="${i}" ${selected.has(i) ? 'checked' : ''}> 第 ${i + 1} 张</label><small id="candy-size-${i}">像素尺寸：加载中…</small><small>${imageSummary(item)}</small></div><div class="candy-compare"><div class="candy-side"><strong>改前 · 原图</strong><img loading="lazy" data-before="${i}" src="${safe(item.url)}" alt="第 ${i + 1} 张原图"></div><div class="candy-side"><strong class="candy-after-title">改后 · 实时预览</strong><img loading="lazy" data-after="${i}" src="${safe(item.keep ? item.url : preview(item))}" style="filter:${item.keep || imageMode(item) === 'selective' ? 'none' : filter(item)}" alt="第 ${i + 1} 张改色预览"><canvas data-canvas="${i}" class="hidden" role="img" aria-label="第 ${i + 1} 张指定颜色预览"></canvas></div></div><div class="candy-row-tools"><button class="drawer-button" type="button" data-edit="${i}">单独调这张</button><button class="drawer-button" type="button" data-reset="${i}">恢复原色</button><button class="drawer-button candy-row-protect" type="button" data-protect="${i}" ${imageMode(item) !== 'selective' || item.keep ? 'disabled' : ''} title="指定颜色模式中，可保护不想改色的部分">${item.protection?.length ? '编辑保护区域' : '保护区域'}</button><button class="drawer-button" type="button" data-download="${i}">下载这张原图 ↓</button><button class="drawer-button" type="button" data-save-original="${i}">原图存入当前相册</button><label class="drawer-button">上传手改图<input data-override="${i}" type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/avif,image/bmp" hidden></label><label><input type="checkbox" data-keep="${i}" ${item.keep ? 'checked' : ''}> 保持原图链</label></div><p class="candy-image-status" role="status" aria-live="polite"></p><small class="candy-link">${safe(item.url)}</small></article>`).join('') || '<div class="empty">没有找到图片图链，仍可以修改下方颜色。</div>';
    $('candy-images').querySelectorAll('[data-before]').forEach(img => {
      img.onload = () => { const size = $(`candy-size-${img.dataset.before}`); if (size) size.textContent = `像素尺寸：${img.naturalWidth} × ${img.naturalHeight} px`; };
      img.onerror = () => { const size = $(`candy-size-${img.dataset.before}`); if (size) size.textContent = '原站无法预览，可尝试下载或上传手改图'; };
      if (img.complete && img.naturalWidth) img.onload();
    });
    $('candy-images').querySelectorAll('[data-image-row]').forEach(row => imageObserver.observe(row));
    updateSelection(); updatePreview();
  }
  function renderColors() {
    $('candy-color-count').textContent = `共 ${project.colors.length} 处`;
    const scroll = $('candy-colors').scrollTop;
    $('candy-colors').innerHTML = project.colors.map((color, i) => `<div class="candy-color-row ${mappedFrom === i ? 'is-map-source' : ''}" data-color-row="${i}"><label class="candy-color-pick"><input type="checkbox" data-color-pick="${i}" ${selectedColors.has(i) ? 'checked' : ''}><span>${i + 1}. ${safe(color.label)}</span></label><span title="原值：${safe(color.original)}"><i class="candy-swatch" style="background:${safe(color.hex)}"></i>原色 RGB(${colorRgb(color.original)})</span><div class="candy-color-edit"><label><input type="color" data-color="${i}" value="${safe(project.changes[i] || color.hex)}" aria-label="修改第 ${i + 1} 处颜色"><code>RGB(${colorRgb(project.changes[i] || color.hex)})</code></label><button type="button" data-color-family="${i}" title="使用这处原色选择相近的色系">选这个色系</button><button type="button" data-color-map="${i}" title="将原色到当前颜色的变化应用到勾选的其他颜色">用作映射样本</button><button type="button" data-color-reset="${i}">还原</button></div></div>`).join('') || '<div class="hint">没有识别到十六进制或 RGB / RGBA 颜色。</div>';
    $('candy-colors').scrollTop = scroll;
    $('candy-color-selected-count').textContent = `已选 ${selectedColors.size} 处颜色`;
    updateFamilyHint();
  }
  function render() {
    themePreview.markDirty();
    activeRuleIndex = 0;
    $('candy-editor').classList.remove('hidden'); $('candy-title').value = project.name;
    $('candy-clear').disabled = false;
    selected.clear(); if (project.images.length) selected.add(0);
    selectedColors.clear(); mappedFrom = -1; $('candy-map-status').textContent = '';
    project.colors.forEach((_, i) => selectedColors.add(i));
    renderImages(); renderColors(); status(`找到 ${project.images.length} 张图、${project.colors.length} 处颜色。预览与草稿仅保存在本机，最终导出时才上传新图片。`);
  }
  async function load(file) {
    if (busy) return notice('请等当前改色任务完成', true);
    if (!file?.name.toLowerCase().endsWith('.json') || file.size > 5 * 1048576) return notice('请选择 5 MB 以内的美化 .json', true);
    try {
      const raw = await file.text(), inspected = inspectTheme(raw);
      release();
      project = { id: crypto.randomUUID(), raw, name: `${inspected.name || file.name.replace(/\.json$/i, '')}-糖果色`, images: inspected.images.map(url => ({ url, hue: 0, sat: 100, light: 100, keep: false, override: null, savedUrl: '' })), colors: inspected.colors, changes: {} };
      project.colorSchema=2;
      render();
    } catch (error) { notice(`美化 JSON 无法读取：${error.message}`, true); }
  }
  $('candy-title').addEventListener('input',()=>themePreview.markDirty());
  $('candy-input').addEventListener('change', event => { load(event.target.files[0]); event.target.value = ''; });
  $('candy-drop').addEventListener('dragover', event => { event.preventDefault(); event.currentTarget.classList.add('dragging'); });
  $('candy-drop').addEventListener('dragleave', event => event.currentTarget.classList.remove('dragging'));
  $('candy-drop').addEventListener('drop', event => { event.preventDefault(); event.currentTarget.classList.remove('dragging'); load(event.dataTransfer.files[0]); });
  $('candy-clear').addEventListener('click', () => {
    if (!project || busy) return;
    if (!confirm('清除当前打开的美化和未保存的调整？已保存的草稿与相册图片会保留。')) return;
    release(); project = null; selected.clear(); selectedColors.clear(); mappedFrom = -1; showPalette(false);
    $('candy-editor').classList.add('hidden'); $('candy-clear').disabled = true;
    $('candy-input').value = ''; $('candy-drafts').value = '';
    $('candy-images').replaceChildren(); $('candy-colors').replaceChildren(); $('candy-map-status').textContent = ''; status('');
    notice('当前美化已清除，可以选择另一份美化 ♡');
  });
  $('candy-open-draft').addEventListener('click', async () => {
    const id = $('candy-drafts').value; if (!id) return notice('先选一份本机草稿', true);
    try {
      const saved = await drafts('readonly', store => store.get(id));
      if (!saved || saved.userId !== state.user?.id) throw new Error('没有找到这份草稿');
      release(); project = saved.project;
      if(project.colorSchema!==2){project.changes=migrateColorChanges(project.raw,project.changes);project.colorSchema=2;}
      project.colors = inspectTheme(project.raw).colors;
      const existing=new Map(project.images.map(item=>[item.url,item]));
      project.images=inspectTheme(project.raw).images.map(url=>existing.get(url)||{url,hue:0,sat:100,light:100,keep:false,override:null,savedUrl:''});
      for (const item of project.images) if (item.override) item.overrideUrl = URL.createObjectURL(item.override);
      render(); notice('草稿已经打开 ♡');
    } catch (error) { notice(`打开草稿失败：${error.message}`, true); }
  });
  $('candy-save-draft').addEventListener('click', async () => {
    if (!project) return;
    project.name = $('candy-title').value.trim();
    if (!project.name) return notice('先给新美化起一个名字', true);
    try {
      const copy = { ...project, images: project.images.map(({ overrideUrl, ...image }) => image), colors: undefined };
      await drafts('readwrite', store => store.put({ id: project.id, userId: state.user.id, name: project.name, updatedAt: Date.now(), project: copy }));
      await refreshDrafts(); status('草稿已保存到此浏览器。清除浏览器网站数据会同时删除草稿。');
    } catch (error) { notice(`草稿保存失败：${error.message}`, true); }
  });
  $('candy-images').addEventListener('change', event => {
    const target = event.target;
    if (target.dataset.pick !== undefined) { const n = Number(target.dataset.pick); target.checked ? selected.add(n) : selected.delete(n); updateSelection(); }
    if (target.dataset.keep !== undefined) { const item = project.images[Number(target.dataset.keep)]; item.keep = target.checked; item.savedUrl = ''; updatePreview(); themePreview.markDirty(); }
    if (target.dataset.override !== undefined) {
      const file = target.files[0], item = project.images[Number(target.dataset.override)];
      if (!file) return;
      if (!uploadTypes.has(file.type) || file.size > 25 * 1048576) return notice('请选择 25 MB 以内的 PNG、JPEG、WebP、GIF、AVIF 或 BMP 图片', true);
      if (item.overrideUrl) URL.revokeObjectURL(item.overrideUrl);
      item.override = file; item.overrideUrl = URL.createObjectURL(file); item.keep = false; item.savedUrl = '';
      item.protection = [];
      themePreview.markDirty();
      renderImages(); status(`第 ${Number(target.dataset.override) + 1} 张已换成你上传的手改图。`);
    }
  });
  $('candy-images').addEventListener('click', async event => {
    const button = event.target.closest('button'); if (!button || !project) return;
    if (button.dataset.protect !== undefined && !busy) {
      const index = Number(button.dataset.protect), item = project.images[index];
      if (imageMode(item) === 'selective' && !item.keep) { setPicking(false); protector.open(item, index); }
    }
    if (button.dataset.edit !== undefined) { selected.clear(); selected.add(Number(button.dataset.edit)); renderImages(); showPalette(true); (imageMode(project.images[Number(button.dataset.edit)]) === 'selective' ? $('candy-recolor-target') : $('candy-hue-number')).focus(); }
    if (button.dataset.reset !== undefined) {
      const item = project.images[Number(button.dataset.reset)];
      if (item.overrideUrl) URL.revokeObjectURL(item.overrideUrl);
      Object.assign(item, { hue: 0, sat: 100, light: 100, mode: 'global', recolor: { ...DEFAULT_RECOLOR }, recolors: [], protection: [], override: null, overrideUrl: '', keep: false, savedUrl: '' }); renderImages();
      themePreview.markDirty();
    }
    if (button.dataset.download !== undefined) try { await downloadOriginal(Number(button.dataset.download)); } catch (error) { notice(error.message, true); }
    if (button.dataset.saveOriginal !== undefined) {
      if (!state.albumId) return notice('请先创建一个相册', true);
      button.disabled = true;
      try {
        const i = Number(button.dataset.saveOriginal), blob = await sourceBlob(project.images[i].url), form = new FormData();
        form.set('albumId', state.albumId); form.set('file', blob, shortName(`${project.name}-原图`, i));
        await api('files', { method: 'POST', body: form });
        await Promise.all([refreshProfile(), refreshAlbums()]); notice('原图已放进当前相册 ♡');
      } catch (error) { notice(error.message, true); } finally { button.disabled = false; }
    }
  });
  $('candy-select-all').addEventListener('click', () => { project?.images.forEach((_, i) => selected.add(i)); renderImages(); });
  $('candy-select-none').addEventListener('click', () => { selected.clear(); renderImages(); });
  $('candy-reset-selected').addEventListener('click', () => { for (const n of selected) { const item = project.images[n]; if (item.overrideUrl) URL.revokeObjectURL(item.overrideUrl); Object.assign(item, { hue: 0, sat: 100, light: 100, mode: 'global', recolor: { ...DEFAULT_RECOLOR }, recolors: [], protection: [], override: null, overrideUrl: '', keep: false, savedUrl: '' }); } renderImages(); themePreview.markDirty(); });
  $('candy-palette-open').addEventListener('click', () => showPalette($('candy-palette').classList.contains('hidden')));
  $('candy-palette-close').addEventListener('click', () => showPalette(false));
  function updateSummaries() {
    $('candy-images').querySelectorAll('[data-image-row]').forEach(row => {
      row.querySelector('.candy-row-top small:last-child').textContent = imageSummary(project.images[Number(row.dataset.imageRow)]);
    });
    updateProtectionButtons();
  }
  function updateProtectionButtons() {
    if (!project) return;
    $('candy-images').querySelectorAll('[data-protect]').forEach(button => {
      const item = project.images[Number(button.dataset.protect)];
      button.disabled = imageMode(item) !== 'selective' || item.keep;
      button.textContent = item.protection?.length ? '编辑保护区域' : '保护区域';
    });
    syncPalette();
  }
  $('candy-protection-open').addEventListener('click', () => {
    if (!project || !selected.size || busy) return;
    const index = [...selected][0], item = project.images[index];
    if (imageMode(item) === 'selective' && !item.keep) { setPicking(false); protector.open(item, index); }
  });
  $('candy-palette').querySelectorAll('[data-candy-mode]').forEach(button => button.addEventListener('click', () => {
    if (!project || !selected.size || busy) return;
    setPicking(false);
    for (const n of selected) {
      const item = project.images[n];
      item.mode = button.dataset.candyMode; item.recolor ||= { ...DEFAULT_RECOLOR };
      item.keep = false; item.savedUrl = '';
    }
    syncPalette(); updateSummaries(); updatePreview(); themePreview.markDirty();
  }));
  function changeRule(change) {
    if (!project || !selected.size || busy) return;
    const first = project.images[[...selected][0]], rules = structuredClone(imageRules(first));
    rules[activeRuleIndex] = { ...rules[activeRuleIndex], ...change };
    applyRules(rules);
  }
  function applyRules(rules) {
    if (!project || !selected.size || busy) return;
    for (const n of selected) {
      const item = project.images[n];
      item.mode = 'selective'; item.recolors = structuredClone(rules); item.recolor = { ...rules[0] }; item.keep = false; item.savedUrl = '';
    }
    syncPalette(); updateSummaries(); updatePreview();
    themePreview.markDirty();
  }
  $('candy-rule-add').addEventListener('click', () => {
    if (!project || !selected.size || busy) return;
    const rules = structuredClone(imageRules(project.images[[...selected][0]]));
    if (rules.length >= 6) return;
    rules.push({ ...DEFAULT_RECOLOR });
    activeRuleIndex = rules.length - 1; applyRules(rules);
    setPicking(true);
    $('candy-pick-hint').textContent = '点一下原图，选择第 ' + (activeRuleIndex + 1) + ' 条规则要替换的颜色。';
    $('candy-images').querySelector(`[data-before="${[...selected][0]}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('candy-rules').addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || !project || busy) return;
    if (button.dataset.rulePick !== undefined) {
      activeRuleIndex = Number(button.dataset.rulePick); setPicking(false); syncPalette();
    }
    if (button.dataset.ruleDelete !== undefined && selected.size) {
      const rules = structuredClone(imageRules(project.images[[...selected][0]]));
      if (rules.length === 1) return;
      const index = Number(button.dataset.ruleDelete);
      rules.splice(index, 1);
      if (activeRuleIndex > index) activeRuleIndex--;
      activeRuleIndex = Math.min(activeRuleIndex, rules.length - 1); setPicking(false); applyRules(rules);
    }
  });
  for (const key of ['source', 'target', 'range', 'softness']) {
    $('candy-recolor-' + key).addEventListener('input', event => changeRule({ [key]: ['range', 'softness'].includes(key) ? Number(event.target.value) : event.target.value }));
  }
  $('candy-pink-preset').addEventListener('click', () => { setPicking(false); changeRule({ source: DEFAULT_RECOLOR.source, range: DEFAULT_RECOLOR.range }); });
  $('candy-show-mask').addEventListener('change', () => schedulePreview());
  $('candy-pick-color').addEventListener('click', () => {
    if (!project || !selected.size || busy) return;
    setPicking(!picking);
    if (picking) {
      const row = $('candy-images').querySelector(`[data-image-row="${[...selected][0]}"]`);
      row?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      row?.querySelector('[data-before]').focus({ preventScroll: true });
    }
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') setPicking(false); });
  async function pickFromImage(img, clientX, clientY) {
    if (!picking || !project || busy) return;
    const current = project, item = current.images[Number(img.dataset.before)];
    try {
      // Match the displayed original, even when a hand-edited replacement is also present.
      const source = await previewSource({ url: item.url });
      if (current !== project || !picking) return;
      const rect = img.getBoundingClientRect();
      const scale = Math.min(rect.width / source.width, rect.height / source.height);
      const left = rect.left + (rect.width - source.width * scale) / 2, top = rect.top + (rect.height - source.height * scale) / 2;
      const x = (clientX - left) / scale, y = (clientY - top) / scale;
      if (x < 0 || y < 0 || x >= source.width || y >= source.height) {
        $('candy-pick-hint').textContent = '这里是图片旁的留白，请点在原图里。'; return;
      }
      const frame = source.getContext('2d').getImageData(0, 0, source.width, source.height);
      const hex = sampleColor(frame.data, source.width, source.height, x, y);
      changeRule({ source: hex }); setPicking(false);
      $('candy-pick-hint').textContent = `已取色 ${hex.toUpperCase()}，应用到所选 ${selected.size} 张图片。`;
    } catch (error) { if (current === project) $('candy-pick-hint').textContent = error.message; }
  }
  $('candy-images').addEventListener('click', event => {
    const img = event.target.closest('[data-before]');
    if (img) pickFromImage(img, event.clientX, event.clientY);
  });
  $('candy-images').addEventListener('keydown', event => {
    const img = event.target.closest('[data-before]');
    if (picking && img && (event.key === 'Enter' || event.key === ' ')) {
      event.preventDefault(); const rect = img.getBoundingClientRect();
      pickFromImage(img, rect.left + rect.width / 2, rect.top + rect.height / 2);
    }
  });
  let drag = null;
  const palette = $('candy-palette'), handle = $('candy-palette-handle');
  handle.addEventListener('pointerdown', event => {
    if (event.target.closest('button')) return;
    const box = palette.getBoundingClientRect();
    drag = { x: event.clientX - box.left, y: event.clientY - box.top };
    handle.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  handle.addEventListener('pointermove', event => {
    if (!drag) return;
    palette.style.left = `${Math.max(8, Math.min(innerWidth - palette.offsetWidth - 8, event.clientX - drag.x))}px`;
    palette.style.top = `${Math.max(8, Math.min(innerHeight - palette.offsetHeight - 8, event.clientY - drag.y))}px`;
    palette.style.right = 'auto';
    palette.style.bottom = 'auto';
  });
  handle.addEventListener('pointerup', () => { drag = null; });
  handle.addEventListener('pointercancel', () => { drag = null; });
  window.addEventListener('resize', () => {
    if (!palette.style.left) return;
    palette.style.left = `${Math.max(8, Math.min(innerWidth - palette.offsetWidth - 8, parseFloat(palette.style.left)))}px`;
    palette.style.top = `${Math.max(8, Math.min(innerHeight - palette.offsetHeight - 8, parseFloat(palette.style.top)))}px`;
  });
  for (const [key, slider, number] of [['hue','candy-hue','candy-hue-number'],['sat','candy-sat','candy-sat-number'],['light','candy-light','candy-light-number']]) {
    function change(value) {
      if (!Number.isFinite(value) || busy) return;
      const next = Math.max(Number($(slider).min), Math.min(Number($(slider).max), Math.round(value)));
      $(slider).value = next; $(number).value = next;
      if (!project || !selected.size) return status('先选中一张或多张图片再调色。');
      for (const n of selected) { const item = project.images[n]; item[key] = next; item.savedUrl = ''; item.keep = false; }
      updatePreview();
      themePreview.markDirty();
      $('candy-images').querySelectorAll('[data-image-row]').forEach(row => {
        const n = Number(row.dataset.imageRow);
        if (selected.has(n)) row.querySelector('.candy-row-top small:last-child').textContent = imageSummary(project.images[n]);
      });
    }
    $(slider).addEventListener('input', event => change(Number(event.target.value)));
    $(number).addEventListener('input', event => { if (event.target.value !== '') change(Number(event.target.value)); });
    $(number).addEventListener('change', event => { if (event.target.value === '') event.target.value = $(slider).value; else change(Number(event.target.value)); });
  }
  $('candy-color-select-all').addEventListener('click', () => { project?.colors.forEach((_, i) => selectedColors.add(i)); renderColors(); });
  $('candy-color-select-none').addEventListener('click', () => { selectedColors.clear(); renderColors(); });
  function familyOptions(){
    return {range:Number($('candy-family-range').value),scope:$('candy-family-scope').value,protectNeutral:$('candy-family-protect').checked};
  }
  function familyTargets(){
    if(!project)return [];
    const options=familyOptions(),source=$('candy-family-source').value;
    return project.colors.map((color,index)=>({color,index})).filter(({color})=>familyMatches(color,source,options));
  }
  function updateFamilyHint(){
    const targets=familyTargets(),chosen=targets.filter(({index})=>selectedColors.has(index));
    $('candy-family-range-value').textContent=$('candy-family-range').value+'°';
    $('candy-family-status').textContent=project ? `找到 ${targets.length} 处相近色 · 其中已勾选 ${chosen.length} 处` : '先导入美化，再选择一个色系。';
    $('candy-family-select').disabled=!targets.length;
    $('candy-family-apply').disabled=!chosen.length;
  }
  for(const id of ['source','target','range','scope','protect'])$('candy-family-'+id).addEventListener('input',updateFamilyHint);
  function selectFamily(){
    selectedColors.clear();for(const {index}of familyTargets())selectedColors.add(index);renderColors();
  }
  $('candy-family-select').addEventListener('click',selectFamily);
  $('candy-family-apply').addEventListener('click',()=>{
    if(!project||busy)return;
    const targets=familyTargets().filter(({index})=>selectedColors.has(index));
    if(!targets.length)return;
    for(const {color,index}of targets)project.changes[index]=mapFamilyColor(color.hex,$('candy-family-source').value,$('candy-family-target').value);
    renderColors();themePreview.markDirty();
    $('candy-map-status').textContent=`已调整 ${targets.length} 处所选相近色，保留原有深浅和透明度。`;
  });
  $('candy-colors').addEventListener('change', event => {
    const input = event.target.closest('[data-color-pick]'); if (!input) return;
    const n = Number(input.dataset.colorPick);
    input.checked ? selectedColors.add(n) : selectedColors.delete(n);
    $('candy-color-selected-count').textContent = `已选 ${selectedColors.size} 处颜色`;
    updateFamilyHint();
  });
  $('candy-colors').addEventListener('input', event => {
    const input = event.target.closest('[data-color]'); if (!input || !project) return;
    const n = Number(input.dataset.color), row = input.closest('.candy-color-row');
    project.changes[n] = input.value; row.querySelector('code').textContent = `RGB(${colorRgb(input.value)})`;
    themePreview.markDirty();
  });
  $('candy-colors').addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || !project) return;
    if(button.dataset.colorFamily!==undefined){
      const color=project.colors[Number(button.dataset.colorFamily)];
      $('candy-family-source').value=color.hex;$('candy-family-panel').open=true;selectFamily();
      $('candy-family-panel').scrollIntoView({behavior:'smooth',block:'nearest'});
    }
    if (button.dataset.colorMap !== undefined) {
      const n = Number(button.dataset.colorMap), before = project.colors[n].hex, after = project.changes[n] || before;
      if (before === after) return notice('请先把这处颜色从 A 调成 B，再用它作为映射样本', true);
      const targets = [...selectedColors].filter(i => i !== n && (!$('candy-family-protect').checked || !isNeutralColor(project.colors[i].hex)));
      if (!targets.length) return notice('请先勾选至少一处其他颜色作为映射目标', true);
      for (const i of targets) project.changes[i] = mapColor(project.colors[i].hex, before, after);
      mappedFrom = n; renderColors();
      themePreview.markDirty();
      const message = `已按第 ${n + 1} 处 A → B 的变化，映射 ${targets.length} 处所选颜色。原色和未勾选的颜色没有更改。`;
      $('candy-map-status').textContent = message; status(message);
    }
    if (button.dataset.colorReset !== undefined) {
      const n = Number(button.dataset.colorReset), row = button.closest('.candy-color-row');
      delete project.changes[n]; row.querySelector('input[type=color]').value = project.colors[n].hex;
      themePreview.markDirty();
      row.querySelector('code').textContent = `RGB(${colorRgb(project.colors[n].hex)})`;
    }
  });
  async function sourceBlob(url) {
    const source = new URL(url);
    const response = source.origin === location.origin
      ? await fetch(source.href, { credentials: 'same-origin' })
      : await fetch('/api/studio/candy/source', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }) });
    if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.error || `图片读取失败 (${response.status})，可下载后手动上传替换`); }
    const blob = await response.blob(); if (!uploadTypes.has(blob.type) || blob.size > 25 * 1048576) throw new Error('原图不是受支持的 25 MB 以内图片');
    return blob;
  }
  async function downloadOriginal(index) {
    const item = project.images[index], blob = await sourceBlob(item.url), objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a'); anchor.href = objectUrl; anchor.download = `${String(project.name).replace(/[\\/:*?"<>|]/g, '_').slice(0, 40)}-原图-${index + 1}.${blob.type.split('/')[1].replace('jpeg', 'jpg')}`;
    anchor.click(); setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
  }
  $('candy-download-all').addEventListener('click', async event => {
    if (!project || busy) return; const button = event.currentTarget; busy = true; button.disabled = true;
    try { for (let i = 0; i < project.images.length; i++) { status(`正在下载第 ${i + 1} / ${project.images.length} 张原图…`); await downloadOriginal(i); } status('原图已逐张下载；如果浏览器拦截多文件下载，请允许本站下载多个文件。'); }
    catch (error) { notice(error.message, true); } finally { busy = false; button.disabled = false; }
  });
  async function recolored(item) {
    const blob = item.override || await sourceBlob(item.url), bitmap = await waitImage(blob);
    try {
      if (bitmap.width * bitmap.height > 20_000_000) throw new Error('单张图片超过 2000 万像素，请先缩小原图');
      const canvas = document.createElement('canvas'); canvas.width = bitmap.width; canvas.height = bitmap.height;
      const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('浏览器无法创建画布');
      if (imageMode(item) !== 'selective' && typeof ctx.filter !== 'string' && (item.hue !== 0 || item.sat !== 100 || item.light !== 100)) throw new Error('此浏览器不支持画布调色，请换用新版浏览器');
      ctx.filter = imageMode(item) === 'selective' ? 'none' : filter(item); ctx.drawImage(bitmap, 0, 0);
      if (imageMode(item) === 'selective') await recolorCanvas(canvas, imageRules(item), { yieldToUI: true, strokes: item.protection });
      const output = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
      canvas.width = 0; canvas.height = 0;
      if (!output || output.size > 25 * 1048576) throw new Error('生成的 PNG 超过单张 25 MB，请缩小图片');
      return output;
    } finally { bitmap.close(); }
  }
  $('candy-export').addEventListener('click', async event => {
    if (!project || busy) return;
    const button = event.currentTarget;
    const title = $('candy-title').value.trim(); if (!title) return notice('请先填写新美化名称', true);
    const modified = project.images.map((item, i) => ({ item, i })).filter(({ item }) => !item.keep && edited(item));
    const changes = new Map(Object.entries(project.changes).map(([index, hex]) => [Number(index), hex]));
    if (!modified.length && !changes.size) return notice('请至少修改一张图片或一处颜色', true);
    busy = true; button.disabled = true;
    try {
      await refreshQuota();
      project.name = title;
      await api('candy/claim', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ projectId: project.id }) });
      await refreshQuota();
      const replacements = new Map();
      if (modified.length) {
        if (modified.some(({ item }) => !item.savedUrl) && !project.albumId) { const album = await api('albums', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: title.slice(0, 80) }) }); project.albumId = album.id; }
        for (const { item, i } of modified) {
          if (!item.savedUrl) {
            status(`正在处理并保存第 ${i + 1} / ${project.images.length} 张图片…`);
            const blob = await recolored(item), form = new FormData();
            form.set('albumId', project.albumId); form.set('file', blob, shortName(title, i));
            const saved = await api('files', { method: 'POST', body: form }); item.savedUrl = saved.url;
          }
          replacements.set(item.url, item.savedUrl);
        }
        await Promise.all([refreshProfile(), refreshAlbums()]);
      }
      const output = exportTheme(project.raw, title, replacements, changes);
      const objectUrl = URL.createObjectURL(new Blob([output], { type: 'application/json;charset=utf-8' }));
      const anchor = document.createElement('a'); anchor.href = objectUrl; anchor.download = `${title.replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').slice(0, 100)}.json`;
      anchor.click(); setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      project.id = crypto.randomUUID(); project.albumId = '';
      status(`完成！新美化「${title}」已下载。修改后的图片保存在刚创建的相册，原图和原美化均未改动。`);
    } catch (error) { status(`暂停：${error.message}。已完成的图片仍在相册里，可保存草稿后重试。`); notice(error.message, true); }
    finally { busy = false; button.disabled = false; }
  });
  return { refreshQuota, refreshDrafts };
}

