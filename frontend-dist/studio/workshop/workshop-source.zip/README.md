# 丘丘美化工坊

A static, isolated SillyTavern appearance editor. SPDX-License-Identifier: AGPL-3.0-or-later (except separately licensed third-party fonts and Font Awesome files).

## Files

- `index.html`, `editor.css`, `editor.js`: responsive editor, dimensions/zoom, theme/project import and export, IndexedDB draft, read-only Studio album picker.
- `core.mjs`: pure import/export, viewport normalization, image URL validation and reversible avatar CSS patches.
- `frame.html`: selected DOM fragments from SillyTavern 1.19.0 commit `06bde939fb1e9c4c8d8641d810f0a916b5bce127`; simplified drawer contents.
- `frame.css`, `frame.js`: preview-only glue and simulated UI state. No SillyTavern API or original chat runtime is loaded.
- `vendor/sillytavern`: upstream style files and fonts. Two fonts are also embedded as data URLs in CSS because the sandbox has an opaque origin. The original standalone font bytes are retained.
- `NOTICE.html`, `licenses`: attribution, changes, scope and license texts.
- `workshop-source.zip`: corresponding source archive for users. Rebuild it whenever changing this module. Exclude the archive itself to avoid recursion; retain all editable files and third-party notices.

Serve over HTTP(S), not by opening index.html from file://. Place this directory at `/studio/workshop/`. The existing root Studio index only needs a link to this path. CSS previews and drafts work without signing in; the album picker requires an existing same-origin Studio login.

The sandbox has only `allow-scripts`, with no same-origin privilege. Parent/frame messages validate the source window and per-load channel. Only the trusted frame runtime has a CSP nonce. Imported CSS is assigned via `textContent`; sample text is escaped and passed through a deliberately limited formatter. Frames cannot fetch APIs or submit forms. External stylesheet/image/font references are still loaded as resources when supplied by the theme.

The UI explicitly separates viewport size from display scale. CSS breakpoints use iframe CSS-pixel dimensions, including when the display scale is 50%. Browser engine, device pixel ratio, OS keyboard and Tauri are not emulated.

User exports preserve unknown theme fields. Preview-only settings are saved in `.workshop.json` files, not SillyTavern theme JSON. Current IndexedDB draft is local to one browser and origin; users should export backups.

## Verification (2026-10-04)

- 7 Node tests: theme field preservation, project roundtrip, invalid JSON handling, scoped/reversible avatar rules, viewport limits, image URL filtering and sandbox configuration.
- Chromium browser checks at 1500×1000 and 390×844: CSS updates, real viewport breakpoints, zoom independence, user/parent CSS isolation, blocked parent DOM access, HTML/script text not executed, local font/icon loading, theme JSON roundtrip, avatar adjustments, element picking, menus/edit state, refresh/draft persistence, mobile tabs, scroll preservation, and album UI against mocked read-only API responses.
- No browser page/console errors or failed HTTP requests during these checks.
- Existing Studio homepage verified to differ only by the new navigation link.
- The real production album login/API and iOS Safari/Tauri have not been exercised by these local checks.

This package does not deploy or push changes to the original repository.

## 2026-10-14 · Candy preview bridge

- The Studio candy editor can open this same isolated preview runtime on demand. Its refresh button sends a snapshot of the current JSON/CSS and small PNG assets; slider changes never trigger whole-theme renders automatically.
- The trusted parent sends PNG Blobs with unique preview-only keys. The child creates its own object URLs, replaces those keys in the snapshot, and releases prior assets after replacement. Arbitrary imported blob URLs remain rejected by the regular image URL helper.
- Frame sandbox, per-load channel checks, CSP, escaped sample text and blocked API/form access are retained. Ordinary Workshop editing continues to work without an asset payload.
- Corresponding source for the Studio bridge is included under integration/ in workshop-source.zip. User-facing exports continue to use the canonical upload flow and do not contain preview-only keys.


## 2026-10-05 · v2

- `inspector.js`: DOM-derived selectors, current-node/ancestor/overlap navigation, user/character/all/single-node scope, pseudo-element inspection and computed properties. Existing ID/class information comes from actual preview DOM; transient editor markers are excluded.
- `inspector-ui.mjs`: inspection panel, code-search handoff, searchable official-source catalog and explicit visible/hidden/unmounted statuses.
- `selector-catalog.mjs`: 68 curated entries plus source-derived names (1,888 entries total). Source: upstream public/index.html, plus known dynamic loader nodes verified in action-loader.js. Catalog membership is not a promise of preview coverage.
- `search.mjs`: literal string search with optional case sensitivity, original-text offsets, previous/next wrapping, literal replacements (including dollar signs), current line/column and line navigation. Ctrl/Cmd+F opens search; Ctrl/Cmd+G opens line jump; Enter/Shift+Enter navigate while search has focus. Editor undo/redo covers replacements.
- `sample.scene` adds chat/preloader/loader in the existing v1 project schema. Existing IndexedDB draft database/key is retained; old drafts default to chat. Scene settings remain outside exported theme JSON.
- Added initial preloader and simulated loader scene using upstream IDs, with an editor-side exit button. Full popup orchestration is not emulated.
- Cache version 20261005a is applied to editor/frame scripts, styles and module imports.

Validation: 11 unit tests plus Chromium desktop/mobile checks, including 140-line search navigation, literal replacement and undo, ancestor switching, pseudo content, all-message scope, loaders, missing-node catalog handling, arbitrary input inspection and mobile horizontal-overflow checks. Existing v1 draft, export, viewport, isolation and mocked album tests also pass. Production account APIs and Safari/Tauri are still untested locally.

## 2026-11-05 · Interactive preview and TauriTavern

- Added `frame-ui.js`: nine distinct preview drawers, synchronized open/closed icons and ARIA state, keyboard support, outside-click/Escape dismissal, 13 chat-menu items, extension menu, local appearance dialogs, quick replies and composer/script states. No chat operations or extension execution are performed.
- The trusted editor and Candy whole-theme preview expose a menu selector outside the imported theme. This can open drawers even if custom CSS decorations intercept the toolbar. Frame root height is explicit so bottom-anchored menus remain in the viewport.
- Environment selection switches between retained SillyTavern styles and TauriTavern base/mobile styles at commit `fff9af0333be97697be2313981699ab0ce35c236`. Imported styles, fonts and referenced SVGs are included locally. Tauri OLED mode uses upstream CSS and its real `tt-oled-background` root class. Tauri settings content is an appearance sample.
- Runtime, OLED, quick replies and composer state are preview-only sample fields, saved in existing v1 workshop drafts/projects. Old drafts receive defaults. Theme JSON exports keep unknown fields and do not gain preview settings. No database migration or backend change is required.
- Candy continues to rebuild image snapshots only on its preview/refresh buttons. Changing preview environment or opening a menu reuses the existing sandbox and assets without uploads or image reprocessing.
- Production Discord membership/quota copy (including dondon) is retained in the Studio integration files.

Validation: 28 Node tests; Chromium browser checks in desktop and mobile editor layouts, including all nine drawers, bottom menus, dialogs, blocked-decoration fallback, CSS preservation across runtime changes, 1280px/390px viewports, Tauri/OLED, generating/script states, quick replies, draft recovery, zero mutation requests and opaque-parent isolation. Standalone previews and Candy integration are checked separately during delivery.

The preview uses this browser's rendering engine. Native Android/iOS WebView differences, OS keyboard/insets, platform fonts, full Tauri host APIs and third-party plugin runtimes are not emulated. Confirm final artwork on the target app when those differences matter.

Tests:

    node --test tests/workshop-preview.test.mjs
    node tests/workshop-preview-browser.mjs

Browser tests require Playwright and Chromium. Set PLAYWRIGHT_MODULE to an installed module URL and CHROME_PATH to an existing Chrome executable if needed. SCREENSHOT_DIR optionally saves screenshots. To serve locally: node tests/workshop-preview-server.mjs, then open its printed URL.

## 2026-11-06 · Composer correction

Removed the two continue/impersonate composer nodes and their UI switch. Legacy composerActions is normalized to false. Added the theme-compatible quick-reply-rocket-button QR assistant sample and input_helper_toolbar; it inserts local text only. Existing menu actions remain appearance samples.
